from django.apps import AppConfig


class AdmnConfig(AppConfig):
    name = 'admn'
